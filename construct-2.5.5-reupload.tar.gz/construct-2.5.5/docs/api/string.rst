=======
Strings
=======

Strings in Construct work very much like strings in other languages.

.. autofunction:: construct.String

.. autofunction:: construct.PascalString

.. autofunction:: construct.CString
