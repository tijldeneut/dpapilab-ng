================================
``construct.debug`` -- Debugging
================================

.. automodule:: construct.debug
