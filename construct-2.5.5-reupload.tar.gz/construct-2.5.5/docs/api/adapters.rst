==================================
``construct.adapters`` -- Adapters
==================================

.. automodule:: construct.adapters
