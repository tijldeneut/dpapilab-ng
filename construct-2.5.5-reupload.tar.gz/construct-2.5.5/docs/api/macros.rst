==============================
``construct.macros`` -- Macros
==============================

.. automodule:: construct.macros
