==========================================
``construct.core`` -- Core data structures
==========================================

.. automodule:: construct.core
